'use strict';
const {app} = require("./app");
const {initLionelServer} = require("lionel-app/bin/initLionelServer");
const { jsFolder, viewFolder, libFolder, port, mainDirectory, separator, appData} = require("./constants");

/**
 * Start HTTP/HTTS Server
 * @type {Array|*}
 */
initLionelServer(port,{
	appData: appData,
	appName: 'Your example Lionel Server',
	lib:libFolder,
	view:viewFolder,
	js:jsFolder,
	debug:true,
	mainDirectory:mainDirectory,
	separator:separator,
	requestListener:app
});

/**
 * Initialize routes for the webPage
 */
require('./app/routes.js');

/**
 * Start Server Backend codes
 */
require('./app/server/index');
