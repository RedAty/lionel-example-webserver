LionelClient.call('getSampleText',function (error, result) {
	console.log(error,result)
});

LionelClient.call('getSampleJSON').then(function (result) {
	console.log(result);
}).catch(function (error) {
	console.warn(error);
});
